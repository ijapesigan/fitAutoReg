library(testthat)
library(fitAutoReg)

test_check("fitAutoReg")
