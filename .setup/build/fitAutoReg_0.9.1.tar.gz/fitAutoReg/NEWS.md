# fitAutoReg 0.0.0.9000 (development version)

- Fitting function
    - VAR(p) OLS for constant vector, auto and cross regression coefficients
    - VAR(p) Lasso for auto and cross regression coefficients
    - VAR(p = 1) and VAR(p = 2) dynr
      - Single VAR on the entire data set wih multiple individuals
      - Separate VAR on each of the individuals
- Bootstrap functions (OLS and Lasso)
    - Residual bootstrap
    - Parametric bootstrap
