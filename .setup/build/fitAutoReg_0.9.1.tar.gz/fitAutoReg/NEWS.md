# fitAutoReg 0.0.0.9000 (development version)

- Fitting function
    - VAR(p) OLS for constant vector, auto and cross regression coefficients
    - VAR(p) Lasso for auto and cross regression coefficients
