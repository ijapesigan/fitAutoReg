#' @aliases fitAutoReg-package
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib fitAutoReg, .registration = TRUE
## usethis namespace: end
NULL
